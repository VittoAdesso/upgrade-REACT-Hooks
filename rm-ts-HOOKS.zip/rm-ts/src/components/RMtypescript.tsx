import React from "react";
import { Character } from "../models/model";

export const RMtypescript: React.FC = () => {
  const [characterList, setCharacterList] = React.useState<Character[]>([]);

  React.useEffect(() => {
    (async () => {
      let data = await fetch(`https://rickandmortyapi.com/api/character/`).then(
        (res) => res.json()
      );
      setCharacterList(data.results);
    })();
  }, []);

  return (
    <>
      {characterList.map((character) => (
        <div key={character.id}>
          <h2>name: {character.name}</h2>
        </div>
      ))}
    </>
  );
};
