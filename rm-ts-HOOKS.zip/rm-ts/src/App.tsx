import { RMtypescript } from "./components/RMtypescript";

function App() {
  return (
    <div>
      <h2>DEMO TYPESCRIPT</h2>
      <RMtypescript />
    </div>
  );
}

export default App;
