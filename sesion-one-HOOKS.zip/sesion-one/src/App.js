// import { MyStateOne } from './components/MyStateOne';
// import { MyEffectOne } from './components/MyEffectOne';
import { UHdemoObjectState } from './components/UHdemoObjectState';
import { UHdemoEffectOnLoad } from './components/UHdemoEffectOnLoad';
import { UHdemoEffectUnmount } from './components/UHdemoEffectUnmount';
import { UHdemoEffectUpdate } from './components/UHdemoEffectUpdate';
import { UHdemoFetchingInput } from './components/UHdemoFetchingInput';
import { UHdemoCustomHook } from './components/UHdemoCustomHook';

function App() {
  return (
    <div className="App">
      {/* <h2>State One example</h2>
      <MyStateOne /> */}
      {/* <h2>UseEffect One example</h2>
      <MyEffectOne /> */}
      <h2>DEMO STATE OBJETC</h2>
      <UHdemoObjectState />
      <h2>DEMO EFFECT COMPONENT ON LOAD</h2>
      <UHdemoEffectOnLoad />
      <h2>DEMO EFFECT COMPONENT UNMOUNT</h2>
      <UHdemoEffectUnmount />
      <h2>DEMO EFFECT COMPONENT UPDATE</h2>
      <UHdemoEffectUpdate />
      <h2>DEMO EFFECT FETCHING REAL TIME</h2>
      <UHdemoFetchingInput />
      <h2>DEMO CUSTOM HOOK FILTER</h2>
      <UHdemoCustomHook />

    </div>
  );
}

export default App;
