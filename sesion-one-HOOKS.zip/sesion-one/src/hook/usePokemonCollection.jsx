import React from 'react'

export const usePokemonCollection = () => {
    const [filter, setFilter] = React.useState("");
    const [pokemonCollection, setPokemonCollection] = React.useState([]);

    const loadPokemons = () => {
        fetch(`https://pokeapi.co/api/v2/pokemon/${filter}`)
            .then((response) => response.json())
            .then((json) => setPokemonCollection([json]))
    }
    return { filter, setFilter, pokemonCollection, loadPokemons }
}